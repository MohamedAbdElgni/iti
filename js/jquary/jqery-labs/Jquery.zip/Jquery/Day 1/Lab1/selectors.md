1. in section with class container1 => 
		- Make the Background of every DIV like its class name and the text color of paragraph like its class name. (Dynamically). [Hint: Use each()][Bonus].

2. [Select Two][The others will be Bonus]
   in section with class container2 => 
   - Replace the text content of the anchors (HREF which contains word "google") with "Google".

   - Replace the text content of the anchors (HREF which ends with word "org") with "IEEE".

   - Replace the text content of the anchors (HREF which starts with word "https") with "Facebook".

   - Append the word "Official Website" text content of the anchors (HREF which starts with word "http").

3. in section with class container3 =>
	- Find the image in the third figure and change it's src to 'img/orange.png' and the text content of its figcaption into "fig.3 - Orange Juice". 
	[Solve it in two Step][Bonus: 1 step]

4.  in section with class container4 =>
	- Find the td which has class "my-name" and change it's color to "blue". 
	[Use: attribute method not class method].

	- Change the background of odd cells (td) in the table into pink color.

	- Find the second (td) of the last (tr) of the first table and change it's font weight to "Bold".

5. in section with class container5 =>
	- Find the second list item of the unordered list and change it's font style to "italic".

	- Find the next direct sibling to second list item of the ordered list and change it's color to "red".