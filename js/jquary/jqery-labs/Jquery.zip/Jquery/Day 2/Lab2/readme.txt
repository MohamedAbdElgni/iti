Required Assignments to be delivered:
=====================================

1- Font Resizer.
2- Box Animator.
3- Box Generator.
4- Author any basic jQuery Plugin ( except greenify :D )


Bonus Assignments:
===================

1- CRUD.
2- Guess My Name Game.


Extra-bonus Assignment:
=======================

1- Make a really good jQuery Plugin (not simple :D).

 ===================
|jQuery Plugin Idea | --> TextHighlighter --> It takes from user the text you want to hoighlight and the 
 ===================
highlight color --> then in the html you can highlight only the text that match the word you enter.

this is just an idea .. please open your mind and if you have another idea implement it immediately.


											
----------------------------------------------| Thank You |-------------------------------------------------------